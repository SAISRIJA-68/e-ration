class Complaint < ApplicationRecord
  belongs_to :user
  belongs_to :shop, optional: true
  enum status: { open: 0, investigating: 1, resolved: 2 }
end
