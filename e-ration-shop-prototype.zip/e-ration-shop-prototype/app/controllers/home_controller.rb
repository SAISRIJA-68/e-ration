class HomeController < ApplicationController
  def index
    @shops = Shop.limit(10)
  end
end
