class CreateShops < ActiveRecord::Migration[7.0]
  def change
    create_table :shops do |t|
      t.references :user, foreign_key: true
      t.string :name
      t.string :address
      t.float :latitude
      t.float :longitude
      t.text :opening_hours
      t.text :ad_text
      t.boolean :active, default: true
      t.timestamps
    end
  end
end
