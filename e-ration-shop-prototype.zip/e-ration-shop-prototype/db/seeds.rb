# Seed sample data
admin = User.create!(email: 'admin@example.com', password: 'password', role: :admin, name: 'Admin', aadhaar_sim: 'ADM001')
shopkeeper = User.create!(email: 'shop1@example.com', password: 'password', role: :shopkeeper, name: 'Ram', aadhaar_sim: 'SHOP001')
shop = Shop.create!(user: shopkeeper, name: 'Ram FPS', address: 'Village Road, SomeCity', opening_hours: { monday: '9-1,3-6' }, ad_text: 'Rice discount')
shop.products.create!(name: 'Wheat (1kg)', category: 'Grains', price: 20.0, stock_level: 100)
shop.products.create!(name: 'Rice (1kg)', category: 'Grains', price: 25.0, stock_level: 80)
user = User.create!(email: 'user1@example.com', password: 'password', role: :card_holder, name: 'Sita', aadhaar_sim: 'USER001')
puts "Seeded: admin, shopkeeper, shop, products, user"
