class Shop < ApplicationRecord
  belongs_to :user, optional: true
  has_many :products, dependent: :destroy

  geocoded_by :address
  after_validation :geocode, if: ->(obj){ obj.address.present? and obj.address_changed? }

  serialize :opening_hours, JSON
end
