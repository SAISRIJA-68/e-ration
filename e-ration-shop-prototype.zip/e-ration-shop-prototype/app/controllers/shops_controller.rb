class ShopsController < ApplicationController
  before_action :authenticate_user!, except: [:index, :show]
  before_action :set_shop, only: [:show, :edit, :update, :destroy]

  def index
    @shops = Shop.all
  end

  def show
  end

  def new
    @shop = current_user.build_shop
  end

  def create
    @shop = current_user.build_shop(shop_params)
    if @shop.save
      redirect_to @shop, notice: "Shop created"
    else
      render :new
    end
  end

  private
  def set_shop
    @shop = Shop.find(params[:id])
  end

  def shop_params
    params.require(:shop).permit(:name, :address, :ad_text, :opening_hours, :active)
  end
end
