class User < ApplicationRecord
  # Roles: card_holder, shopkeeper, admin
  enum role: { card_holder: 0, shopkeeper: 1, admin: 2 }
  devise :database_authenticatable, :registerable,
         :recoverable, :rememberable, :validatable

  has_one :shop, dependent: :destroy
  has_many :orders, foreign_key: :customer_id
  has_many :complaints

  validates :aadhaar_sim, presence: true, uniqueness: true
end
