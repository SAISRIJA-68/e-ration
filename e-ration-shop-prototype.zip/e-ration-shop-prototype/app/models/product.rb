class Product < ApplicationRecord
  belongs_to :shop
  validates :name, :category, :price, presence: true
end
