class ProductsController < ApplicationController
  before_action :set_shop, only: [:index, :new, :create]

  def index
    @products = @shop.products
  end

  def show
    @product = Product.find(params[:id])
  end

  def new
    @product = @shop.products.build
  end

  def create
    @product = @shop.products.build(product_params)
    if @product.save
      redirect_to shop_products_path(@shop), notice: "Product added"
    else
      render :new
    end
  end

  private
  def set_shop
    @shop = Shop.find(params[:shop_id])
  end

  def product_params
    params.require(:product).permit(:name, :category, :price, :stock_level, :description)
  end
end
