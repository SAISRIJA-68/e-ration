class OrdersController < ApplicationController
  before_action :authenticate_user!

  def create
    shop = Shop.find(params[:shop_id])
    order = Order.new(customer: current_user, shop: shop, status: :placed, payment_method: params[:payment_method])
    # Simplified: create order items from params[:items]
    if order.save
      redirect_to order_path(order), notice: "Order placed"
    else
      redirect_back fallback_location: shop_path(shop), alert: "Failed to place order"
    end
  end

  def show
    @order = Order.find(params[:id])
  end
end
