class Order < ApplicationRecord
  belongs_to :customer, class_name: 'User'
  belongs_to :shop
  enum status: { placed: 0, confirmed: 1, packed: 2, out_for_delivery: 3, delivered: 4, canceled: 5 }
  enum payment_method: { cod: 0, paytm_sim: 1 }
end
