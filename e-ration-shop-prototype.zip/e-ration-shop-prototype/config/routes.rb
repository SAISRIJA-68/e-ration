Rails.application.routes.draw do
  root "home#index"
  devise_for :users
  resources :shops do
    resources :products, only: [:index, :show, :new, :create]
    resources :orders, only: [:index, :create, :show]
  end
  resources :products, only: [:edit, :update, :destroy]
  resources :orders, only: [:update]
  resources :complaints, only: [:new, :create, :index, :show]
  namespace :admin do
    resources :shops
    resources :users
    resources :complaints
    get "reports", to: "reports#index"
  end
  namespace :api do
    namespace :v1 do
      post 'auth/send_otp'
      post 'auth/verify_otp'
      resources :shops, only: [:index, :show]
    end
  end
end
